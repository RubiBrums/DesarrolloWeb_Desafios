precio = 3550

precioSpan = document.querySelector(".precio-inicial");
precioSpan.innerHTML = precio